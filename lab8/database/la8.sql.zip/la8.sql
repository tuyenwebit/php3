-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th4 06, 2025 lúc 06:31 PM
-- Phiên bản máy phục vụ: 10.4.32-MariaDB
-- Phiên bản PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `la8`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `loai_san_phams`
--

CREATE TABLE `loai_san_phams` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ten_loai` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `loai_san_phams`
--

INSERT INTO `loai_san_phams` (`id`, `ten_loai`, `created_at`, `updated_at`) VALUES
(1, 'Điện thoại', '2025-04-06 08:58:58', '2025-04-06 08:58:58'),
(2, 'Máy tính bảng', '2025-04-06 08:58:58', '2025-04-06 08:58:58');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2025_04_06_145032_create_products_table', 1),
(2, '2025_04_06_154946_create_loai_san_phams_table', 2);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `description`, `created_at`, `updated_at`) VALUES
(1, 'fuga', 174.25, 'Odio incidunt repellendus ut nesciunt ratione et aut hic.', '2025-04-06 07:55:42', '2025-04-06 07:55:42'),
(2, 'itaque', 263.72, 'Laudantium fugiat et repudiandae et molestiae illum.', '2025-04-06 07:55:42', '2025-04-06 07:55:42'),
(3, 'sit', 273.77, 'Mollitia qui sint est molestias ipsa et.', '2025-04-06 07:55:42', '2025-04-06 07:55:42'),
(4, 'totam', 841.72, 'Officia rerum et nisi et animi sed itaque.', '2025-04-06 07:55:42', '2025-04-06 07:55:42'),
(5, 'et', 951.90, 'Cumque ut esse voluptatem consequatur.', '2025-04-06 07:55:42', '2025-04-06 07:55:42'),
(6, 'temporibus', 15.67, 'Sunt aut quibusdam quis nisi nam maxime molestiae.', '2025-04-06 07:55:42', '2025-04-06 07:55:42'),
(7, 'quam', 657.43, 'Distinctio neque ut quia distinctio.', '2025-04-06 07:55:42', '2025-04-06 07:55:42'),
(8, 'tempora', 412.39, 'Et quaerat omnis nobis cupiditate.', '2025-04-06 07:55:42', '2025-04-06 07:55:42'),
(9, 'quidem', 50.81, 'Vitae iste soluta natus.', '2025-04-06 07:55:42', '2025-04-06 07:55:42'),
(10, 'repudiandae', 677.36, 'Minus deleniti molestias delectus inventore dolorum.', '2025-04-06 07:55:42', '2025-04-06 07:55:42');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `loai_san_phams`
--
ALTER TABLE `loai_san_phams`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `loai_san_phams`
--
ALTER TABLE `loai_san_phams`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT cho bảng `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT cho bảng `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
